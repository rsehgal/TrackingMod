
        #!/bin/bash
        for i in `seq 1 50`;
        do
            echo $i
            ./daq904
        done
echo "how was the lunch guys?"
